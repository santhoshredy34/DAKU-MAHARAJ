# EcoCup - A Flask-based Sustainability Tracker

## Features
- Track reusable cup usage
- Earn rewards for sustainable behavior
- Simple and user-friendly interface

## Installation
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run the app:
   ```bash
   python app.py
   ```
3. Open http://127.0.0.1:5000/ in your browser.
